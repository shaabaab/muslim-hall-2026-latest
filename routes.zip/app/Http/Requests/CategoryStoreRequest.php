<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CategoryStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'status' => 'nullable|boolean',
            'lang_id' => 'required|integer|exists:languages,id',
            'parent_id' => 'nullable|integer|exists:categories,id',
            'img' => 'nullable|image|mimes:jpg,jpeg,png,webp,gif,svg,bmp,avif|max:51200',
        ];
    }
}
