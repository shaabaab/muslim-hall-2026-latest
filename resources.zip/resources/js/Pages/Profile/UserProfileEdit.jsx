import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import UserDelete from './Partials/UserDelete';
import UpdatePasswordForm from './Partials/UpdatePasswordForm';
import UserUpdateProfile from './Partials/UserUpdateProfile';
import { Head } from '@inertiajs/react';
import FrontAuthenticatedLayout from '../../Layouts/FrontAuthenticatedLayout';

export default function Edit({ auth, mustVerifyEmail, status }) {
    return (
        <FrontAuthenticatedLayout
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">Profile</h2>}
        >
            <Head title="Profile" />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
                    <div className="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                        <UserUpdateProfile
                            mustVerifyEmail={mustVerifyEmail}
                            status={status}
                            className="max-w-xl"
                        />
                    </div>

                    <div className="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                        <UpdatePasswordForm className="max-w-xl" />
                    </div>

                    <div className="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                        <UserDelete className="max-w-xl" />
                    </div>
                </div>
            </div>
        </FrontAuthenticatedLayout>
    );
}
